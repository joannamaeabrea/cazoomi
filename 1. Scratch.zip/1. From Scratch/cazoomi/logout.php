<?php
	include "config.php";
  	session_start();
    session_destroy();
?>
    <script>window.location.href="/cazoomi/home"</script>
