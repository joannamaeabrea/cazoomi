<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="assets/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="assets/vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="assets/build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <?php
      include "config.php";

      if(isset($_POST['login']))
      {
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        //All Database Queries go here
        //Query access_registry
        $register_query = "SELECT * FROM access_registry WHERE username=:username AND password=:password";
        $stmt = $db->prepare($register_query);
        $stmt->execute(array('username' => $username, 'password' => $password));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $user = $row['username'];
        $pass = $row['password'];
        $user_id = $row['user_id'];
        $access_id = $row['access_id'];

        //Query access_control
        $access_query = "SELECT * FROM access_control WHERE access_id=:access_id";
        $stmt = $db->prepare($access_query);
        $stmt->execute(array('access_id' => $access_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $access_type = $row['access_type'];

        //Query users
        $users_query = "SELECT * FROM users WHERE user_id=:user_id";
        $stmt = $db->prepare($users_query);
        $stmt->execute(array('user_id' => $user_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $fullname = $row['fullname'];
        $email_address = $row['email_address'];

        if($username==$user && $pass==$password)
        {
          session_start();

          //Access Type
          $_SESSION['access_id'] = $access_id;
          $_SESSION['access_type'] = $access_type;
          //User
          $_SESSION['user_id'] = $user_id;
          $_SESSION['fullname'] = $fullname;
          $_SESSION['email_address'] = $email_address;

          ?>
          <script>window.location.href="dashboard.php"</script>
          <?php
        }
        else
        {
          echo "Sorry! Incorrect username or password";
        }
      }
    ?>

    <?php
      if(isset($_POST['register']))
      {
        //Insert into users table
        $stmt1 = $db->prepare("INSERT INTO users (fullname, email_address) VALUES (:Fullname, :Email_Address)");
        $stmt1->bindParam(':Fullname', $Fullname);
        $stmt1->bindParam(':Email_Address', $Email_Address);
        $Fullname = $_POST['fullname'];
        $Email_Address = $_POST['email_address'];
        $stmt1->execute();

        //Query Log Details
        $users_query = "SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1";
        $stmt2 = $db->prepare($users_query);
        $stmt2->execute();
        $row = $stmt2->fetch(PDO::FETCH_ASSOC);
        $user_id = $row['user_id'];

        //Insert into access registry table
        $stmt3 = $db->prepare("INSERT INTO access_registry (access_id, user_id, username, password) VALUES (:Access_Id, :User_Id, :Username, :Password)");
        $stmt3->bindParam(':Access_Id', $Access_Id);
        $stmt3->bindParam(':User_Id', $User_Id);
        $stmt3->bindParam(':Username', $Username);
        $stmt3->bindParam(':Password', $Password);
        $Access_Id  = '2';
        $User_Id  = $user_id;
        $Username   = $_POST['username'];
        $Password   = md5($_POST['password']);
        $stmt3->execute();

        //Access Type
        $access_type = 'User';

        session_start();

        //Access Type
        $_SESSION['access_type'] = $access_type;
        //User
        $_SESSION['fullname'] = $_POST['fullname'];
        $_SESSION['email_address'] = $_POST['email_address'];

        ?>
        <script>window.location.href="dashboard.php"</script>
        <?php
      }
      ?>

    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form method="POST">
              <h1>Login Form</h1>
              <div>
                <input type="text" class="form-control" placeholder="Username" name="username" required="" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" name="password" required="" />
              </div>
              <div>
                <input type="submit" value="Login" class="btn btn-default" name="login" />
              </div>
            </form>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

              </div>
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form method="POST">
              <h1>Create Account</h1>
              <div>
                <input type="text" class="form-control" placeholder="Full Name" name="fullname" required="" />
              </div>
              <div>
                <input type="email" class="form-control" placeholder="Email" name="email_address" required="" />
              </div>
              <div>
                <input type="text" class="form-control" placeholder="Username" name="username" required="" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" name="password" required="" />
              </div>
              <div>
                <input type="submit" value="Register" class="btn btn-primary" name="register" />
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
