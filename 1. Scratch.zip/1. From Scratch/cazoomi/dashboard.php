<?php
  include "config.php";
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <?php
    include("includes/head.html");
  ?>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php
          include("includes/body-nav.html");
        ?>
        <!-- page content -->
        <?php
          if($_SESSION['access_type']=='Administrator'){
        ?>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Users</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="clearfix"></div>

            <?php
              if(isset($_POST['adduser'])){
                //Insert into users table
                $stmt1 = $db->prepare("INSERT INTO users (fullname, email_address) VALUES (:Fullname, :Email_Address)");
                $stmt1->bindParam(':Fullname', $Fullname);
                $stmt1->bindParam(':Email_Address', $Email_Address);
                $Fullname = $_POST['fullname'];
                $Email_Address = $_POST['email_address'];
                $stmt1->execute();

                //Query Log Details
                $users_query = "SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1";
                $stmt2 = $db->prepare($users_query);
                $stmt2->execute();
                $row = $stmt2->fetch(PDO::FETCH_ASSOC);
                $user_id = $row['user_id'];

                //Insert into access registry table
                $stmt3 = $db->prepare("INSERT INTO access_registry (access_id, user_id, username, password) VALUES (:Access_Id, :User_Id, :Username, :Password)");
                $stmt3->bindParam(':Access_Id', $Access_Id);
                $stmt3->bindParam(':User_Id', $User_Id);
                $stmt3->bindParam(':Username', $Username);
                $stmt3->bindParam(':Password', $Password);
                $Access_Id  = '2';
                $User_Id  = $user_id;
                $Username   = $_POST['username'];
                $Password   = md5($_POST['password']);
                $stmt3->execute();

                ?>
                  <script>window.location.href="dashboard.php"</script>
                <?php
              }
            ?>

            <div class="row">
              <div class="clearfix"></div>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_content">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                      Add User
                    </button>

                    <!-- Modal -->
                    <div class="modal fade bs-example-modal-md" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                      <div class="modal-dialog modal-md" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel">User Information</h4>
                          </div>
                          <div class="modal-body">
                            <form data-parsley-validate class="form-horizontal form-label-left" method="POST">
                                <div class="form-group">
                                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">User ID</label>
                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" class="form-control col-md-7 col-xs-12" readonly="readonly"/>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Full Name <span class="required">*</span></label>
                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12" type="text" name="fullname" required />
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Email Address  <span class="required">*</span></label>
                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12" type="email" name="email_address" required/>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Username <span class="required">*</span></label>
                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12" type="text" name="username" required />
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Password  <span class="required">*</span></label>
                                  <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12" type="password" name="password" required/>
                                  </div>
                                </div>
                                <br>
                                <center>
                                    <input type="submit" value="Add User" class="btn btn-primary" name="adduser" />
                                </center>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <!-- Employee Masterlist -->
            <div class="row">
              <div class="clearfix"></div>
              <div class="col-md-12 col-sm-12 col-xs-12" width="708px">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Users Masterlist</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a href=""><i class="fa fa-plus"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <!-- Query for Updating/Deleting User -->
                  <?php 
                    if(isset($_POST['update_user']))
                    {
                      $user_id = $_POST["user_id"];
                      $fullname = $_POST["fullname"];
                      $email_address = $_POST["email_address"];
                      $username = $_POST["username"];
                      $password = md5($_POST["password"]);
                      $access_id = $_POST["access_id"];

                      $stmt1 = $db->prepare("UPDATE users SET fullname='".$fullname."', email_address='".$email_address."' WHERE user_id='".$user_id."'");
                      $stmt1->execute();

                      $stmt2 = $db->prepare("UPDATE access_registry SET access_id='".$access_id."', username='".$username."', password='".$password."' WHERE user_id='".$user_id."'");
                      $stmt2->execute();
                      ?>
                      <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <strong>Thank you!</strong> User successfully updated.
                      </div>
                      <?php
                    }
                    else if(isset($_POST['delete_user']))
                    {
                      $user_id = $_POST["user_id"];
                      $fullname = $_POST["fullname"];
                      $email_address = $_POST["email_address"];
                      $username = $_POST["username"];
                      $password = md5($_POST["password"]);
                      $access_id = $_POST["access_id"];

                      $stmt1 = $db->prepare("DELETE FROM users WHERE user_id='".$user_id."'");
                      $stmt1->execute();

                      $stmt2 = $db->prepare("DELETE FROM access_registry WHERE user_id='".$user_id."'");
                      $stmt2->execute();
                      ?>
                      <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <strong>Thank you!</strong> User successfully deleted.
                      </div>                  
                      <?php
                    }
                  ?>
                  <div class="x_content">
                    <div class="table-responsive">
                      <table id="datatable" class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title no-link last">Action</th>
                            <th class="column-title">User ID</th>
                            <th class="column-title">Access Type</th>
                            <th class="column-title">Full Name</th>
                            <th class="column-title">Email Address</th>
                            <th class="column-title">Username</th>
                            <th class="column-title">Password</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                              $users_query = "SELECT * FROM users
                                              INNER JOIN access_registry ON users.user_id=access_registry.user_id
                                              INNER JOIN access_control ON access_registry.access_id=access_control.access_id";
                              $stmt = $db->prepare($users_query);
                              $stmt->execute();
                              while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                              ?>
                                <tr>
                                  <?php $rowID = $row['user_id']; ?>
                                  <td class="last"><a href="#" data-toggle="modal" data-target="#editModal<?php echo $rowID; ?>" data-sfid="<?php echo $rowID; ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>
                                  <td><?php echo $row["user_id"]; ?></td>
                                  <td><?php echo $row["access_type"]; ?></td>
                                  <td><?php echo $row["fullname"]; ?></td>
                                  <td><?php echo $row["email_address"]; ?></td>
                                  <td><?php echo $row["username"]; ?></td>
                                  <td><?php echo $row["password"]; ?></td>
                                </tr>
                              <?php
                              }
                            ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <!-- Modal for Updating User -->
                  <?php
                    $user_query = "SELECT * FROM users
                                    INNER JOIN access_registry ON users.user_id=access_registry.user_id
                                    INNER JOIN access_control ON access_registry.access_id=access_control.access_id";
                    $stmt = $db->prepare($user_query);
                    $stmt->execute();
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                  ?>
                  <!-- EDIT MODAL -->
                  <div class="modal fade bs-example-modal-md" id="editModal<?php echo $row['user_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog modal-md" role="document">
                    <div class="modal-content" style="width: 800px;padding-left:2em;" >
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">User Information</h4>
                      </div>
                      <div class="modal-body">
                        <div>
                          <form data-parsley-validate class="form-horizontal form-label-left" method="POST">
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">User ID</label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input class="form-control col-md-7 col-xs-12" type="text" readonly="readonly" value="<?php echo $row['user_id'] ?>"  name="user_id" />
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Access Type
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="select2_single form-control" tabindex="-1" required name="access_id">
                                  <option value="1">Administrator</option>
                                  <option value="2" selected>User</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Full Name
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $row['fullname']; ?>" name="fullname" />
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Email Address
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $row['email_address']; ?>" name="email_address" />
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Username
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $row['username']; ?>" name="username" />
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Password
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $row['password']; ?>" name="password" />
                              </div>
                            </div>
                            <div class="ln_solid"></div>
                            <center>
                              <button type="submit" class="btn btn-success" name="update_user">Update</button>
                              <button type="submit" class="btn btn-danger" name="delete_user">Delete</button>
                            </center>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  <?php 
                    }
                  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php
          }
          else if($_SESSION['access_type']=='User'){
        ?>

          <div class="right_col" role="main">
            <div class="">
              <div class="page-title">
                <div class="title_left">
                  <h3>Welcome <?php echo $_SESSION['fullname'];?>!</h3>
                </div>
              </div>
            </div>
          </div>
        <?php
          }
        ?>
        <!-- /page content -->
      </div>
    </div>
  </body>
  <footer>
        <?php
          include("includes/foot.html");
        ?>
  </footer>
</html>